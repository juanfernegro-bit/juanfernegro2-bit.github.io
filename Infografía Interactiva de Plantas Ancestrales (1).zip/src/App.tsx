import { useRef, useState } from "react"
import ThreeSpecimen from "./ThreeSpecimen"

type PlantId = "cannabis" | "hongos" | "cactaceas" | "solanaceas" | "ayahuasca"

type Plant = {
  id: PlantId
  number: string
  name: string
  shortName: string
  specimen: string
  compound: string
  formula: string
  note: string
}

type PlantIconProps = {
  id: PlantId
  className?: string
}

type SpecimenArtProps = {
  plant: Plant
  rotation: {
    x: number
    y: number
  }
}

const plants: Plant[] = [
  {
    id: "cannabis",
    number: "01",
    name: "Cannabis",
    shortName: "Cannabis",
    specimen: "Cogollo de marihuana",
    compound: "THC",
    formula: "Tetrahidrocannabinol",
    note: "Fitocannabinoide presente en las flores de Cannabis sativa.",
  },
  {
    id: "hongos",
    number: "02",
    name: "Hongos sagrados",
    shortName: "Hongos",
    specimen: "Hongo Psilocibe",
    compound: "Psilocibina",
    formula: "4-PO-DMT",
    note: "Alcaloide triptamínico presente en distintas especies de Psilocybe.",
  },
  {
    id: "cactaceas",
    number: "03",
    name: "Cactáceas",
    shortName: "Cactáceas",
    specimen: "Cactus Peyote",
    compound: "Mescalina",
    formula: "3,4,5-trimetoxifenetilamina",
    note: "Alcaloide encontrado principalmente en el cactus Lophophora williamsii.",
  },
  {
    id: "solanaceas",
    number: "04",
    name: "Solanáceas",
    shortName: "Solanáceas",
    specimen: "Flor de Floripondio",
    compound: "Norescopolamina",
    formula: "Alcaloide tropánico",
    note: "Compuesto asociado a especies del género Brugmansia.",
  },
  {
    id: "ayahuasca",
    number: "05",
    name: "Ayahuasca",
    shortName: "Ayahuasca",
    specimen: "Corte de tronco de Ayahuasca",
    compound: "DMT",
    formula: "N,N-dimetiltriptamina",
    note: "Triptamina vinculada a preparaciones botánicas amazónicas tradicionales.",
  },
]

function PlantIcon({ id, className = "" }: PlantIconProps) {
  const common = {
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  }

  if (id === "cannabis") {
    return (
      <svg viewBox="0 0 80 80" className={className} aria-hidden="true">
        <g {...common}>
          <path d="M40 68V24" />
          <path d="M40 50C29 47 20 41 13 32c11 0 20 3 27 11" />
          <path d="M40 43C30 34 26 23 25 10c9 7 14 16 15 28" />
          <path d="M40 39C40 24 45 13 52 5c2 14-2 26-12 38" />
          <path d="M41 47c9-11 18-16 28-17-5 11-14 18-28 23" />
          <path d="M40 57c-7-2-13-1-19 2 5 5 11 6 19 3" />
          <path d="M42 57c7-4 13-4 19-2-4 6-10 8-19 7" />
        </g>
      </svg>
    )
  }

  if (id === "hongos") {
    return (
      <svg viewBox="0 0 80 80" className={className} aria-hidden="true">
        <g {...common}>
          <path d="M12 42C12 24 24 13 41 13s29 11 29 29c-10 3-20 2-29-5-8 7-18 8-29 5Z" />
          <path d="M31 40c2 8 1 17-3 26 8 4 16 4 25 0-4-9-5-18-3-26" />
          <path d="M24 37c4-7 9-11 17-12 8 1 13 5 17 12" />
          <path d="M19 46c3 4 7 5 12 4M62 46c-3 4-7 5-12 4" />
        </g>
      </svg>
    )
  }

  if (id === "cactaceas") {
    return (
      <svg viewBox="0 0 80 80" className={className} aria-hidden="true">
        <g {...common}>
          <path d="M30 67c-4-7-6-16-6-27 0-18 6-28 16-28s16 10 16 28c0 11-2 20-6 27Z" />
          <path d="M40 14v52M31 18c4 11 4 28 0 47M49 18c-4 11-4 28 0 47" />
          <path d="M40 12c-3 5-4 9-4 13M40 12c3 5 4 9 4 13" />
          <path d="m40 31-3 2m3 9 3 2m-3 10-3 2" />
          <path d="M20 67h40" />
        </g>
      </svg>
    )
  }

  if (id === "solanaceas") {
    return (
      <svg viewBox="0 0 80 80" className={className} aria-hidden="true">
        <g {...common}>
          <path d="M39 15c-3 9-10 14-21 17 6 4 9 10 9 18 5-3 10-2 15 2 3-6 8-9 15-9-3-6-2-12 4-18-9 0-16-3-22-10Z" />
          <path d="M27 34c9 1 16 5 20 12" />
          <path d="M41 25c-1 10 0 18 5 25" />
          <path d="M46 50c7 4 11 10 12 18" />
          <path d="M33 29c1 4 0 8-3 12" />
          <circle cx="39" cy="17" r="3" />
        </g>
      </svg>
    )
  }

  return (
    <svg viewBox="0 0 80 80" className={className} aria-hidden="true">
      <g {...common}>
        <path d="M13 53c8-20 21-33 39-40 10 9 15 21 15 35-17 2-35 4-54 5Z" />
        <path d="M15 53c15-7 28-18 38-38M25 45c1-8 0-14-3-19M36 37c7-2 14-2 21 0M45 27c1-6 0-10-2-14" />
        <path d="M12 58c15 2 33 0 54-6l2 8c-20 7-39 9-56 6Z" />
        <path d="M24 59c2 3 3 5 2 7m14-8c2 2 3 4 3 6m13-9c2 2 3 4 3 6" />
      </g>
    </svg>
  )
}

function BotanicalPattern() {
  return (
    <svg className="botanical-pattern" aria-hidden="true">
      <defs>
        <pattern
          id="botanical"
          width="280"
          height="280"
          patternUnits="userSpaceOnUse"
        >
          <g fill="none" stroke="currentColor" strokeWidth="1.4" opacity=".55">
            <path d="M54 142C25 118 19 86 30 45c19 21 29 48 26 83 8-31 24-55 48-72-3 34-18 62-47 82 22-16 48-22 77-18-20 22-45 31-76 27" />
            <path d="M214 222v-40c-17 0-28-6-34-18 3-25 17-39 41-42 24 4 38 18 41 42-8 12-20 18-37 18v40" />
            <path d="M182 165c12-13 25-19 39-19s27 6 39 19M194 231c18-8 34-8 49 0" />
            <path d="M94 253c12-22 27-33 45-34 2 17-5 30-21 40M94 253c-3-19-13-31-30-37-6 16-1 30 15 42" />
            <circle cx="218" cy="62" r="25" />
            <path d="M194 62h48M218 38c-8 9-12 17-12 24s4 15 12 24c8-9 12-17 12-24s-4-15-12-24Z" />
          </g>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#botanical)" />
    </svg>
  )
}

function SpecimenArt({ plant, rotation }: SpecimenArtProps) {
  return (
    <div className={`specimen-art specimen-${plant.id}`}>
      <div className="orbit orbit-one" />
      <div className="orbit orbit-two" />
      <div className="three-model">
        <ThreeSpecimen
          id={plant.id}
          rotationX={rotation.x}
          rotationY={rotation.y}
        />
      </div>
      <span className="three-icon-badge">
        <PlantIcon id={plant.id} className="specimen-icon" />
      </span>
      <span className="model-pin pin-one" aria-hidden="true" />
      <span className="model-pin pin-two" aria-hidden="true" />
      <span className="axis axis-x">X</span>
      <span className="axis axis-y">Y</span>
      <span className="axis axis-z">Z</span>
    </div>
  )
}

function ChemicalStructure({ id }: { id: PlantId }) {
  const molecule = {
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  }

  if (id === "cannabis") {
    return (
      <svg
        viewBox="0 0 150 90"
        aria-label="Estructura molecular ilustrada del THC"
      >
        <g {...molecule}>
          <path d="m25 50 14-24h28l14 24-14 24H39Z" />
          <path d="m39 26 14 8m-21 28 21-1m14-35 14-9 24 13 1 27-24 14-15-9" />
          <path d="m106 30 17-10m-17 37 22 12m-47-19 17 1m-59-1-16-8" />
          <path d="m50 74 8 10m9-10 7 10" />
        </g>
        <text x="9" y="43">
          OH
        </text>
        <text x="78" y="16">
          O
        </text>
      </svg>
    )
  }

  if (id === "hongos") {
    return (
      <svg
        viewBox="0 0 150 90"
        aria-label="Estructura molecular ilustrada de la psilocibina"
      >
        <g {...molecule}>
          <path d="m16 55 14-24h28l14 24-14 24H30Z" />
          <path d="m58 31 22 6 9 23-17 15-14 4m22-42 12-14m-3 37 22 8 19-12" />
          <path d="m30 31 14 8M23 66l21-1m14-10 14-8" />
          <path d="m92 23 17-10m0 0 14 8m-14-8V2" />
        </g>
        <text x="49" y="88">
          NH
        </text>
        <text x="84" y="21">
          O
        </text>
        <text x="105" y="12">
          P
        </text>
        <text x="124" y="28">
          O
        </text>
        <text x="112" y="77">
          N
        </text>
      </svg>
    )
  }

  if (id === "cactaceas") {
    return (
      <svg
        viewBox="0 0 150 90"
        aria-label="Estructura molecular ilustrada de la mescalina"
      >
        <g {...molecule}>
          <path d="m39 18 28 1 14 24-15 24-28-1-14-24Z" />
          <path d="m39 25 20 1M73 43 62 61M31 43l10 16" />
          <path d="M39 18 28 5M24 42 8 42M38 66 27 82M81 43l24 1 14 18" />
          <path d="m105 44 12-8" />
        </g>
        <text x="12" y="10">
          OCH₃
        </text>
        <text x="0" y="46">
          OCH₃
        </text>
        <text x="10" y="88">
          OCH₃
        </text>
        <text x="118" y="69">
          NH₂
        </text>
      </svg>
    )
  }

  if (id === "solanaceas") {
    return (
      <svg
        viewBox="0 0 150 90"
        aria-label="Estructura molecular ilustrada de la norescopolamina"
      >
        <g {...molecule}>
          <path d="m22 48 18-27 26 8 8 28-20 20-28-7Z" />
          <path d="m40 21 14 56m12-48 20-14 22 13-2 26-22 11-10-8" />
          <path d="m86 15 8-11m12 50 20 12m-42-1 5 15" />
          <path d="m54 40 14 3m-42 27-12 9" />
        </g>
        <text x="61" y="41">
          N
        </text>
        <text x="89" y="12">
          O
        </text>
        <text x="126" y="73">
          OH
        </text>
        <text x="87" y="88">
          OH
        </text>
      </svg>
    )
  }

  return (
    <svg
      viewBox="0 0 150 90"
      aria-label="Estructura molecular ilustrada del DMT"
    >
      <g {...molecule}>
        <path d="m14 52 14-25h28l14 25-14 24H28Z" />
        <path d="m56 27 23 6 9 23-17 17-15 3M28 27l14 9M21 64l21-1m28-11 15-10" />
        <path d="m88 56 22 8 18-12m-18 12 17 12" />
      </g>
      <text x="46" y="86">
        NH
      </text>
      <text x="128" y="56">
        N
      </text>
    </svg>
  )
}

export default function App() {
  const [selected, setSelected] = useState<PlantId>("cannabis")
  const [rotation, setRotation] = useState({ x: -5, y: 12 })
  const [dragging, setDragging] = useState(false)
  const dragStart = useRef({ x: 0, y: 0, rx: 0, ry: 0 })
  const active = plants.find((plant) => plant.id === selected) ?? plants[0]

  function startDrag(event: React.PointerEvent<HTMLDivElement>) {
    dragStart.current = {
      x: event.clientX,
      y: event.clientY,
      rx: rotation.x,
      ry: rotation.y,
    }
    event.currentTarget.setPointerCapture(event.pointerId)
    setDragging(true)
  }

  function moveDrag(event: React.PointerEvent<HTMLDivElement>) {
    if (!dragging) return
    setRotation({
      x: Math.max(
        -28,
        Math.min(
          28,
          dragStart.current.rx - (event.clientY - dragStart.current.y) * 0.25,
        ),
      ),
      y: dragStart.current.ry + (event.clientX - dragStart.current.x) * 0.35,
    })
  }

  return (
    <main className="app-shell">
      <BotanicalPattern />
      <div className="grain" aria-hidden="true" />

      <header className="topbar">
        <a
          className="brand"
          href="#inicio"
          aria-label="Herbario Alterado, inicio"
        >
          <span className="brand-mark">
            <PlantIcon id="cannabis" />
          </span>
          <span>
            Etnobotánica
            <br />
            <b>para educar</b>
          </span>
        </a>
        <div className="topbar-meta">
          <span>Archivo etnobotánico</span>
          <span className="live-dot">Experiencia interactiva</span>
        </div>
      </header>

      <section className="hero" id="inicio">
        <div className="eyebrow">
          <span>Grupo D</span>
          <span className="eyebrow-divider" aria-hidden="true">
            —
          </span>
          <span>Muestrario herbal digital</span>
        </div>
        <div className="hero-title-wrap">
          <h1>
            <span className="title-lead">Etnobotánica</span>
            <span className="title-middle">y el uso de psicotrópicos</span>
            <span className="title-end">en las civilizaciones antigüas</span>
          </h1>
        </div>
        <section className="historical-context" aria-labelledby="context-title">
          <div className="context-heading">
            <span className="context-index">Archivo / 00</span>
            <h2 id="context-title">Contexto histórico y ritual</h2>
            <span className="context-note">Lectura introductoria</span>
          </div>
          <div className="context-grid">
            <article className="context-card context-card-intro">
              <span className="context-number">01</span>
              <div>
                <h3>Visión ancestral</h3>
                <p>
                  Desde la antigüedad, las civilizaciones y sociedades arcaicas
                  han visto en ciertas plantas elementos sagrados que inspiran
                  tanto temor como veneración debido a sus efectos misteriosos e
                  inexplicables.
                </p>
              </div>
            </article>
            <article className="context-card context-card-intro">
              <span className="context-number">02</span>
              <div>
                <h3>Tránsito ritual</h3>
                <p>
                  El uso ritual de estas plantas ofrecía a las sociedades
                  tradicionales un método directo para trascender los límites de
                  la existencia mundana y entrar en contacto con el mundo
                  espiritual y lo sobrenatural.
                </p>
              </div>
            </article>
            <article className="context-card context-card-feature">
              <span className="context-number">03</span>
              <div>
                <h3>El caso de los huicholes en México</h3>
                <p>
                  Para este pueblo indígena, el peyote (
                  <i>Lophophora williamsii</i>) no es una simple planta, sino
                  una “deidad” o un regalo de la diosa de la Tierra. Lo emplean
                  en celebraciones anuales donde todos los miembros de la tribu
                  lo ingieren para lograr una contemplación y comunicación
                  mística.
                </p>
              </div>
            </article>
            <article className="context-card context-card-feature">
              <span className="context-number">04</span>
              <div>
                <h3>Prácticas chamánicas tradicionales</h3>
                <p>
                  El uso de plantas psicoactivas como el cáñamo (Cannabis) se
                  remonta a tiempos muy antiguos y ha estado vinculado a
                  prácticas de trance ceremonial, como las danzas frenéticas de
                  los chamanes mongoles.
                </p>
              </div>
            </article>
          </div>
        </section>
        <p className="hero-copy">
          Conociendo cinco especies, sus formas y compuestos desde una mirada
          <strong> cultural, botánica y molecular.</strong>
        </p>
        <div className="scroll-cue">
          <span>Explora el archivo</span>
          <span className="arrow">↓</span>
        </div>
      </section>

      <section
        className="experience"
        aria-label="Explorador de plantas ancestrales"
      >
        <div className="menu-panel">
          <div className="section-label">
            <span>Selecciona una especie</span>
            <b>05 registros</b>
          </div>
          <div className="plant-menu" role="list">
            {plants.map((plant) => {
              const isActive = selected === plant.id
              return (
                <button
                  type="button"
                  key={plant.id}
                  className={`plant-card ${isActive ? "active" : ""}`}
                  onClick={() => {
                    setSelected(plant.id)
                    setRotation({ x: -5, y: 12 })
                  }}
                  aria-pressed={isActive}
                  role="listitem"
                >
                  <span className="card-number">{plant.number}</span>
                  <span className="icon-sticker">
                    <PlantIcon id={plant.id} />
                  </span>
                  <span className="card-name">{plant.name}</span>
                  <span className="card-arrow">↗</span>
                </button>
              )
            })}
          </div>
        </div>

        <article className="viewer-card" aria-live="polite">
          <div className="tape tape-left" aria-hidden="true" />
          <div className="viewer-top">
            <span className="specimen-tag">Espécimen {active.number}</span>
            <span className="viewer-status">
              <i /> Modelo digital
            </span>
          </div>
          <div
            className={`viewport ${dragging ? "dragging" : ""}`}
            onPointerDown={startDrag}
            onPointerMove={moveDrag}
            onPointerUp={() => setDragging(false)}
            onPointerCancel={() => setDragging(false)}
            style={
              {
                "--rx": `${rotation.x}deg`,
                "--ry": `${rotation.y}deg`,
              } as React.CSSProperties
            }
            role="img"
            aria-label={`Visor 3D de ${active.specimen}. Arrastra para rotar.`}
          >
            <div className="viewport-grid" />
            <div className="model-stage">
              <SpecimenArt plant={active} rotation={rotation} />
            </div>
            <div className="drag-hint">
              <span className="drag-icon">↔</span>
              Arrastra para rotar
            </div>
            <span className="render-label">Render 3D en tiempo real</span>
            <span className="corner corner-tl" />
            <span className="corner corner-tr" />
            <span className="corner corner-bl" />
            <span className="corner corner-br" />
          </div>

          <div className="specimen-info">
            <div>
              <span className="info-kicker">
                {active.shortName} / Archivo {active.number}
              </span>
              <h2>{active.specimen}</h2>
              <p>{active.note}</p>
            </div>
            <div className="compound-sticker">
              <div className="compound-copy">
                <span>Compuesto clave</span>
                <strong>{active.compound}</strong>
                <small>{active.formula}</small>
              </div>
              <div className="chemical-image">
                <ChemicalStructure id={active.id} />
              </div>
            </div>
          </div>
          <div className="viewer-foot">
            <span>Vista de referencia educativa</span>
            <button type="button" onClick={() => setRotation({ x: -5, y: 12 })}>
              Reiniciar vista
            </button>
          </div>
        </article>
      </section>

      <footer>
        <span>Una cartografía digital de saberes botánicos</span>
        <span>Diseñada para explorar, no para consumir</span>
      </footer>
    </main>
  )
}
