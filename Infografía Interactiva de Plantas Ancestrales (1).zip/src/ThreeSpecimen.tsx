import { useEffect, useRef } from "react"
import * as THREE from "three"

type PlantId = "cannabis" | "hongos" | "cactaceas" | "solanaceas" | "ayahuasca"

type TextureStyle = "leaf" | "bud" | "stem" | "cap" | "gill" | "cactus" | "petal" | "bark" | "wood"

const textureCache = new Map<TextureStyle, {
  map: THREE.CanvasTexture
  bump: THREE.CanvasTexture
}>()

function organicTexture(style: TextureStyle) {
  const cached = textureCache.get(style)
  if (cached) return cached

  const size = 256
  const colorCanvas = document.createElement("canvas")
  const bumpCanvas = document.createElement("canvas")
  colorCanvas.width = bumpCanvas.width = size
  colorCanvas.height = bumpCanvas.height = size
  const colorContext = colorCanvas.getContext("2d")!
  const bumpContext = bumpCanvas.getContext("2d")!
  const colorData = colorContext.createImageData(size, size)
  const bumpData = bumpContext.createImageData(size, size)

  for (let y = 0; y < size; y += 1) {
    for (let x = 0; x < size; x += 1) {
      const index = (y * size + x) * 4
      const fine = seeded(x * 3 + y * 7) * 2 - 1
      const broad = Math.sin(x * 0.075) * Math.cos(y * 0.054)
      let value = 218 + fine * 24 + broad * 11

      if (style === "bark")
        value =
          170 + fine * 35 + Math.sin(x * 0.16 + Math.sin(y * 0.05) * 3) * 30
      if (style === "wood")
        value =
          205 +
          Math.sin(Math.hypot(x - 128, y - 128) * 0.28 + fine) * 28 +
          fine * 8
      if (style === "petal") value = 230 + fine * 8 + Math.sin(x * 0.11) * 8
      if (style === "cactus") value = 210 + fine * 12 + Math.sin(x * 0.2) * 10
      if (style === "cap") value = 196 + fine * 25 + broad * 22
      if (style === "bud") value = 188 + fine * 38 + broad * 18
      if (style === "gill") value = 205 + Math.sin(x * 0.42) * 32 + fine * 6
      if (style === "stem") value = 220 + fine * 13 + Math.sin(x * 0.24) * 14
      if (style === "leaf")
        value = 205 + fine * 15 + Math.sin((x + y) * 0.08) * 10

      const clamped = Math.max(90, Math.min(255, value))
      colorData.data.set([clamped, clamped, clamped, 255], index)
      const bump = Math.max(20, Math.min(245, 128 + (clamped - 200) * 2.2))
      bumpData.data.set([bump, bump, bump, 255], index)
    }
  }

  colorContext.putImageData(colorData, 0, 0)
  bumpContext.putImageData(bumpData, 0, 0)

  if (style === "leaf") {
    colorContext.strokeStyle = "rgba(255,255,255,.22)"
    colorContext.lineWidth = 2
    for (let i = -6; i <= 6; i += 1) {
      colorContext.beginPath()
      colorContext.moveTo(128, 128)
      colorContext.lineTo(128 + i * 24, i < 0 ? 8 : 248)
      colorContext.stroke()
    }
  }

  if (style === "bark") {
    colorContext.strokeStyle = "rgba(40,15,5,.24)"
    bumpContext.strokeStyle = "rgba(25,25,25,.65)"
    for (let i = 0; i < 22; i += 1) {
      const x = seeded(i + 400) * size
      const width = 1 + seeded(i + 500) * 4
      for (const context of [colorContext, bumpContext]) {
        context.lineWidth = width
        context.beginPath()
        context.moveTo(x, 0)
        context.bezierCurveTo(x + 18, 70, x - 15, 170, x + 8, size)
        context.stroke()
      }
    }
  }

  if (style === "wood") {
    colorContext.strokeStyle = "rgba(90,45,18,.34)"
    for (let radius = 18; radius < 180; radius += 17) {
      colorContext.beginPath()
      colorContext.ellipse(
        128,
        128,
        radius,
        radius * 0.88,
        0.15,
        0,
        Math.PI * 2,
      )
      colorContext.stroke()
    }
  }

  if (style === "bud") {
    for (let i = 0; i < 420; i += 1) {
      const x = seeded(i + 1200) * size
      const y = seeded(i + 1500) * size
      const radius = 0.4 + seeded(i + 1800) * 1.5
      const bright = seeded(i + 2100) > 0.4
      colorContext.fillStyle = bright
        ? "rgba(242,255,225,.34)"
        : "rgba(28,46,18,.24)"
      bumpContext.fillStyle = bright
        ? "rgba(225,225,225,.75)"
        : "rgba(55,55,55,.55)"
      for (const context of [colorContext, bumpContext]) {
        context.beginPath()
        context.arc(x, y, radius, 0, Math.PI * 2)
        context.fill()
      }
    }
  }

  const map = new THREE.CanvasTexture(colorCanvas)
  const bump = new THREE.CanvasTexture(bumpCanvas)
  map.colorSpace = THREE.SRGBColorSpace
  map.wrapS = map.wrapT = THREE.RepeatWrapping
  bump.wrapS = bump.wrapT = THREE.RepeatWrapping
  const result = { map, bump }
  textureCache.set(style, result)
  return result
}

const physical = (
  color: number,
  options: Partial<THREE.MeshPhysicalMaterialParameters> = {},
  textureStyle?: TextureStyle,
) => {
  const texture = textureStyle ? organicTexture(textureStyle) : undefined
  return new THREE.MeshPhysicalMaterial({
    color,
    map: texture?.map,
    bumpMap: texture?.bump,
    roughnessMap: texture?.bump,
    bumpScale: textureStyle === "bark" ? 0.13 : textureStyle ? 0.055 : 0,
    roughness: 0.58,
    metalness: 0.02,
    clearcoat: 0.18,
    clearcoatRoughness: 0.7,
    ...options,
  })
}

function seeded(index: number) {
  const value = Math.sin(index * 128.31 + 49.17) * 43758.5453
  return value - Math.floor(value)
}

function createLeaf(color = 0x267d39) {
  const shape = new THREE.Shape()
  shape.moveTo(0, -0.7)
  shape.bezierCurveTo(-0.42, -0.28, -0.5, 0.34, 0, 0.82)
  shape.bezierCurveTo(0.5, 0.34, 0.42, -0.28, 0, -0.7)
  const geometry = new THREE.ShapeGeometry(shape, 12)
  const mesh = new THREE.Mesh(
    geometry,
    physical(color, { side: THREE.DoubleSide, roughness: 0.72 }, "leaf"),
  )
  const vein = new THREE.Mesh(
    new THREE.BoxGeometry(0.018, 1.25, 0.015),
    physical(0x8dbd62, { roughness: 0.8 }),
  )
  vein.position.y = -0.02
  vein.position.z = 0.012
  mesh.add(vein)
  return mesh
}

function createSerratedLeaflet(length = 1, color = 0x3f6532) {
  const shape = new THREE.Shape()
  const segments = 9
  shape.moveTo(0, -0.48 * length)
  for (let i = 1; i < segments; i += 1) {
    const progress = i / segments
    const envelope = Math.sin(progress * Math.PI) * 0.19 * length
    const tooth = i % 2 === 0 ? 0.62 : 1.18
    shape.lineTo(envelope * tooth, (-0.48 + progress * 1.36) * length)
  }
  shape.lineTo(0, 0.98 * length)
  for (let i = segments - 1; i > 0; i -= 1) {
    const progress = i / segments
    const envelope = Math.sin(progress * Math.PI) * 0.19 * length
    const tooth = i % 2 === 0 ? 0.62 : 1.18
    shape.lineTo(-envelope * tooth, (-0.48 + progress * 1.36) * length)
  }
  shape.closePath()

  const leaflet = new THREE.Mesh(
    new THREE.ShapeGeometry(shape, 18),
    physical(
      color,
      { side: THREE.DoubleSide, roughness: 0.82, clearcoat: 0.08 },
      "leaf",
    ),
  )
  const vein = new THREE.Mesh(
    new THREE.BoxGeometry(0.014, 1.25 * length, 0.012),
    physical(0xa0b06d, { roughness: 0.9 }),
  )
  vein.position.y = 0.15 * length
  vein.position.z = 0.014
  leaflet.add(vein)
  return leaflet
}

function createCannabisFanLeaf() {
  const leaf = new THREE.Group()
  const angles = [-1.02, -0.7, -0.38, 0, 0.38, 0.7, 1.02]
  const lengths = [0.58, 0.78, 0.96, 1.08, 0.96, 0.78, 0.58]
  angles.forEach((angle, index) => {
    const leaflet = createSerratedLeaflet(lengths[index], 0x385c2f)
    leaflet.rotation.z = -angle
    leaflet.position.set(Math.sin(angle) * 0.08, 0, index * -0.004)
    leaf.add(leaflet)
  })
  return leaf
}

function createFoldedCalyxGeometry() {
  const geometry = new THREE.SphereGeometry(1, 20, 14)
  const positions = geometry.attributes.position
  const point = new THREE.Vector3()
  for (let i = 0; i < positions.count; i += 1) {
    point.fromBufferAttribute(positions, i)
    const angle = Math.atan2(point.z, point.x)
    const vertical = (point.y + 1) / 2
    const folds = 1 + Math.cos(angle * 5) * 0.075
    const pear = 0.72 + Math.sin(vertical * Math.PI) * 0.28
    point.x *= folds * pear
    point.z *= folds * pear
    point.y *= 1.12
    positions.setXYZ(i, point.x, point.y, point.z)
  }
  geometry.computeVertexNormals()
  return geometry
}

function cannabisModelLegacy() {
  const group = new THREE.Group()
  const budMaterial = physical(
    0x526f35,
    { roughness: 0.9, clearcoat: 0.04 },
    "bud",
  )
  const lightBud = physical(0x78914d, { roughness: 0.93 }, "bud")
  const darkBud = physical(0x334728, { roughness: 0.96 }, "bud")
  const foldedCalyx = createFoldedCalyxGeometry()

  // Dense, tapered core matching the conical silhouette in the reference.
  for (let i = 0; i < 42; i += 1) {
    const angle = i * 2.399
    const height = -1.12 + (i / 41) * 2.35
    const normalizedHeight = (height + 1.12) / 2.35
    const width =
      0.72 -
      normalizedHeight * 0.38 +
      Math.sin(normalizedHeight * Math.PI) * 0.18
    const node = new THREE.Mesh(
      new THREE.DodecahedronGeometry(0.28 + seeded(i) * 0.13, 1),
      i % 7 === 0 ? darkBud : i % 4 === 0 ? lightBud : budMaterial,
    )
    node.position.set(
      Math.cos(angle) * width * (0.48 + seeded(i + 3) * 0.45),
      height,
      Math.sin(angle) * width * (0.48 + seeded(i + 7) * 0.45),
    )
    node.scale.set(0.9, 1.15, 0.85)
    node.rotation.set(seeded(i + 8), angle, seeded(i + 10))
    group.add(node)
  }

  // Overlapping pointed bracts give the bud its leafy, compact surface.
  for (let i = 0; i < 58; i += 1) {
    const height = -1.15 + seeded(i + 40) * 2.25
    const normalizedHeight = (height + 1.15) / 2.25
    const radius =
      0.8 -
      normalizedHeight * 0.43 +
      Math.sin(normalizedHeight * Math.PI) * 0.12
    const angle = i * 2.17
    const bract = new THREE.Mesh(
      new THREE.ConeGeometry(
        0.105 + seeded(i + 90) * 0.07,
        0.38 + seeded(i + 150) * 0.2,
        5,
      ),
      i % 5 === 0 ? lightBud : budMaterial,
    )
    bract.position.set(
      Math.cos(angle) * radius,
      height,
      Math.sin(angle) * radius,
    )
    bract.rotation.set(
      Math.cos(angle) * 0.82 + seeded(i + 220) * 0.35,
      angle,
      -Math.sin(angle) * 0.82,
    )
    group.add(bract)
  }

  // Plump calyxes and their pointed tips recreate the layered floral anatomy.
  for (let i = 0; i < 38; i += 1) {
    const height = -1.02 + seeded(i + 620) * 2.05
    const normalizedHeight = (height + 1.02) / 2.05
    const radius = 0.64 - normalizedHeight * 0.3 + seeded(i + 650) * 0.12
    const angle = i * 2.31
    const calyx = new THREE.Mesh(
      foldedCalyx,
      i % 4 === 0 ? lightBud : budMaterial,
    )
    const calyxSize = 0.18 + seeded(i + 680) * 0.055
    calyx.scale.set(calyxSize * 0.82, calyxSize * 1.45, calyxSize * 0.78)
    calyx.position.set(
      Math.cos(angle) * radius,
      height,
      Math.sin(angle) * radius,
    )
    calyx.rotation.set(Math.cos(angle) * 0.48, angle, -Math.sin(angle) * 0.48)
    group.add(calyx)

    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.075, 0.24, 6), lightBud)
    tip.position.set(
      Math.cos(angle) * (radius + 0.06),
      height + 0.2,
      Math.sin(angle) * (radius + 0.06),
    )
    tip.rotation.set(Math.cos(angle) * 0.36, angle, -Math.sin(angle) * 0.36)
    group.add(tip)
  }

  // Sugar leaves emerge between the floral clusters.
  for (let i = 0; i < 18; i += 1) {
    const angle = (i / 18) * Math.PI * 2
    const sugarLeaf = createSerratedLeaflet(0.44 + seeded(i + 710) * 0.22)
    sugarLeaf.position.set(
      Math.cos(angle) * 0.62,
      -0.72 + seeded(i + 740) * 1.45,
      Math.sin(angle) * 0.62,
    )
    sugarLeaf.rotation.set(
      Math.cos(angle) * 0.72,
      angle,
      -Math.sin(angle) * 0.72,
    )
    group.add(sugarLeaf)
  }

  const pistilMaterial = physical(0xe88332, {
    emissive: 0x381204,
    roughness: 0.7,
  })
  for (let i = 0; i < 46; i += 1) {
    const angle = seeded(i + 30) * Math.PI * 2
    const y = -0.9 + seeded(i + 60) * 1.9
    const radius = 0.56 - Math.abs(y) * 0.08
    const curve = new THREE.QuadraticBezierCurve3(
      new THREE.Vector3(Math.cos(angle) * radius, y, Math.sin(angle) * radius),
      new THREE.Vector3(
        Math.cos(angle + 0.35) * (radius + 0.3),
        y + 0.16,
        Math.sin(angle + 0.35) * (radius + 0.3),
      ),
      new THREE.Vector3(
        Math.cos(angle + 0.65) * (radius + 0.12),
        y + 0.31,
        Math.sin(angle + 0.65) * (radius + 0.12),
      ),
    )
    group.add(
      new THREE.Mesh(
        new THREE.TubeGeometry(curve, 8, 0.014, 4, false),
        pistilMaterial,
      ),
    )
  }

  const trichomePositions: number[] = []
  for (let i = 0; i < 380; i += 1) {
    const angle = seeded(i + 120) * Math.PI * 2
    const y = -1.05 + seeded(i + 330) * 2.1
    const radius = 0.48 - Math.abs(y) * 0.08 + seeded(i + 800) * 0.24
    trichomePositions.push(
      Math.cos(angle) * radius,
      y,
      Math.sin(angle) * radius,
    )
  }
  const trichomes = new THREE.BufferGeometry()
  trichomes.setAttribute(
    "position",
    new THREE.Float32BufferAttribute(trichomePositions, 3),
  )
  group.add(
    new THREE.Points(
      trichomes,
      new THREE.PointsMaterial({
        color: 0xe7ffd8,
        size: 0.026,
        transparent: true,
        opacity: 0.78,
        sizeAttenuation: true,
      }),
    ),
  )

  // Larger gland heads complement the fine point-cloud trichomes.
  const glandGeometry = new THREE.SphereGeometry(0.026, 7, 5)
  const glandMaterial = physical(0xe5edd0, {
    roughness: 0.28,
    clearcoat: 0.75,
    transmission: 0.08,
  })
  for (let i = 0; i < 54; i += 1) {
    const angle = seeded(i + 920) * Math.PI * 2
    const y = -0.96 + seeded(i + 960) * 1.95
    const radius = 0.57 - Math.abs(y) * 0.07 + seeded(i + 1000) * 0.15
    const gland = new THREE.Mesh(glandGeometry, glandMaterial)
    gland.position.set(Math.cos(angle) * radius, y, Math.sin(angle) * radius)
    group.add(gland)
  }

  const frontLeaf = createCannabisFanLeaf()
  frontLeaf.scale.setScalar(0.72)
  frontLeaf.position.set(0, -1.12, 0.68)
  frontLeaf.rotation.x = -0.28
  group.add(frontLeaf)

  for (const side of [-1, 1]) {
    const fanLeaf = createCannabisFanLeaf()
    fanLeaf.scale.setScalar(0.48)
    fanLeaf.position.set(side * 0.54, -0.76, 0.08)
    fanLeaf.rotation.set(-0.45, side * 0.62, side * -0.45)
    group.add(fanLeaf)
  }

  group.scale.set(0.82, 0.92, 0.82)
  group.rotation.z = -0.08
  return group
}

function cannabisModel() {
  const group = new THREE.Group()
  const mainMaterial = physical(
    0x526f38,
    { roughness: 0.84, clearcoat: 0.08 },
    "bud",
  )
  const lightMaterial = physical(
    0x799257,
    { roughness: 0.86, clearcoat: 0.1 },
    "bud",
  )
  const shadowMaterial = physical(0x304428, { roughness: 0.94 }, "bud")

  // A single displaced core prevents the specimen from reading as loose stones.
  const coreGeometry = new THREE.SphereGeometry(1, 52, 38)
  const corePositions = coreGeometry.attributes.position
  const corePoint = new THREE.Vector3()
  for (let i = 0; i < corePositions.count; i += 1) {
    corePoint.fromBufferAttribute(corePositions, i)
    const originalY = corePoint.y
    const height = (originalY + 1) / 2
    const angle = Math.atan2(corePoint.z, corePoint.x)
    const taper = 0.9 - height * 0.42 + Math.sin(height * Math.PI) * 0.12
    const organic =
      1 +
      Math.sin(angle * 7 + originalY * 4.5) * 0.055 +
      Math.sin(angle * 3 - originalY * 8) * 0.035
    corePoint.x *= taper * organic
    corePoint.z *= taper * organic
    corePoint.y *= 1.23
    corePositions.setXYZ(i, corePoint.x, corePoint.y, corePoint.z)
  }
  coreGeometry.computeVertexNormals()
  group.add(new THREE.Mesh(coreGeometry, shadowMaterial))

  const calyxGeometry = createFoldedCalyxGeometry()
  const upAxis = new THREE.Vector3(0, 1, 0)
  const tipGeometry = new THREE.ConeGeometry(0.07, 0.25, 7)

  // Helical layers of plump calyxes define the reference's compact floral body.
  for (let i = 0; i < 72; i += 1) {
    const progress = i / 71
    const y = -1.03 + progress * 2.17
    const angle = i * 2.399
    const envelope = 0.74 - progress * 0.39 + Math.sin(progress * Math.PI) * 0.1
    const radius = envelope * (0.84 + seeded(i + 2300) * 0.16)
    const size = 0.14 + seeded(i + 2400) * 0.075
    const direction = new THREE.Vector3(
      Math.cos(angle) * 0.72,
      0.42 + progress * 0.25,
      Math.sin(angle) * 0.72,
    ).normalize()

    const calyx = new THREE.Mesh(
      calyxGeometry,
      i % 7 === 0 ? lightMaterial : i % 5 === 0 ? shadowMaterial : mainMaterial,
    )
    calyx.scale.set(size * 0.9, size * 1.48, size * 0.82)
    calyx.position.set(Math.cos(angle) * radius, y, Math.sin(angle) * radius)
    calyx.quaternion.setFromUnitVectors(upAxis, direction)
    calyx.rotateY(seeded(i + 2500) * Math.PI)
    group.add(calyx)

    if (i % 2 === 0) {
      const tip = new THREE.Mesh(tipGeometry, lightMaterial)
      tip.scale.setScalar(0.7 + seeded(i + 2600) * 0.45)
      tip.position.copy(calyx.position).addScaledVector(direction, size * 1.34)
      tip.quaternion.copy(calyx.quaternion)
      group.add(tip)
    }
  }

  // Serrated sugar leaves project from the floral mass at irregular intervals.
  for (let i = 0; i < 24; i += 1) {
    const progress = seeded(i + 2700)
    const y = -0.88 + progress * 1.74
    const angle = i * 2.07
    const radius = 0.67 - progress * 0.22
    const direction = new THREE.Vector3(
      Math.cos(angle) * 0.82,
      0.38,
      Math.sin(angle) * 0.82,
    ).normalize()
    const leaf = createSerratedLeaflet(0.38 + seeded(i + 2800) * 0.25)
    leaf.position.set(Math.cos(angle) * radius, y, Math.sin(angle) * radius)
    leaf.quaternion.setFromUnitVectors(upAxis, direction)
    leaf.rotateY(seeded(i + 2900) * 0.45 - 0.22)
    group.add(leaf)
  }

  const pistilMaterial = physical(0xc66b32, {
    roughness: 0.7,
    emissive: 0x2f0d03,
  })
  const pistilHighlightMaterial = physical(0xe28b45, {
    roughness: 0.64,
    emissive: 0x351305,
  })
  for (let i = 0; i < 196; i += 1) {
    const progress = seeded(i + 3000)
    const y = -0.96 + progress * 2.04
    const angle = seeded(i + 3100) * Math.PI * 2
    const radius = 0.52 - progress * 0.15
    const reach = 0.2 + seeded(i + 3150) * 0.22
    const curl = 0.28 + seeded(i + 3180) * 0.58
    const curve = new THREE.CubicBezierCurve3(
      new THREE.Vector3(Math.cos(angle) * radius, y, Math.sin(angle) * radius),
      new THREE.Vector3(
        Math.cos(angle + curl * 0.28) * (radius + reach),
        y + 0.04 + seeded(i + 3200) * 0.08,
        Math.sin(angle + curl * 0.28) * (radius + reach),
      ),
      new THREE.Vector3(
        Math.cos(angle + curl * 0.72) * (radius + reach + 0.05),
        y + 0.18 + seeded(i + 3250) * 0.16,
        Math.sin(angle + curl * 0.72) * (radius + reach + 0.05),
      ),
      new THREE.Vector3(
        Math.cos(angle + curl) * (radius + reach * 0.55),
        y + 0.28 + seeded(i + 3280) * 0.16,
        Math.sin(angle + curl) * (radius + reach * 0.55),
      ),
    )
    group.add(
      new THREE.Mesh(
        new THREE.TubeGeometry(
          curve,
          12,
          0.009 + seeded(i + 3290) * 0.005,
          5,
          false,
        ),
        i % 4 === 0 ? pistilHighlightMaterial : pistilMaterial,
      ),
    )
  }

  const trichomePositions: number[] = []
  for (let i = 0; i < 640; i += 1) {
    const progress = seeded(i + 3300)
    const y = -1.02 + progress * 2.08
    const angle = seeded(i + 3400) * Math.PI * 2
    const envelope =
      0.74 - progress * 0.37 + Math.sin(progress * Math.PI) * 0.09
    const radius = envelope + seeded(i + 3500) * 0.12
    trichomePositions.push(
      Math.cos(angle) * radius,
      y,
      Math.sin(angle) * radius,
    )
  }
  const trichomeGeometry = new THREE.BufferGeometry()
  trichomeGeometry.setAttribute(
    "position",
    new THREE.Float32BufferAttribute(trichomePositions, 3),
  )
  group.add(
    new THREE.Points(
      trichomeGeometry,
      new THREE.PointsMaterial({
        color: 0xf0f5db,
        size: 0.023,
        transparent: true,
        opacity: 0.88,
      }),
    ),
  )

  const glandGeometry = new THREE.SphereGeometry(0.024, 7, 5)
  const glandMaterial = physical(0xe4ebc9, {
    roughness: 0.22,
    clearcoat: 0.82,
  })
  for (let i = 0; i < 68; i += 1) {
    const progress = seeded(i + 3600)
    const y = -0.94 + progress * 1.92
    const angle = seeded(i + 3700) * Math.PI * 2
    const radius = 0.71 - progress * 0.3 + seeded(i + 3800) * 0.13
    const gland = new THREE.Mesh(glandGeometry, glandMaterial)
    gland.position.set(Math.cos(angle) * radius, y, Math.sin(angle) * radius)
    group.add(gland)
  }

  const frontLeaf = createCannabisFanLeaf()
  frontLeaf.scale.setScalar(0.7)
  frontLeaf.position.set(0, -1.12, 0.73)
  frontLeaf.rotation.x = -0.3
  group.add(frontLeaf)
  for (const side of [-1, 1]) {
    const leaf = createCannabisFanLeaf()
    leaf.scale.setScalar(0.42)
    leaf.position.set(side * 0.5, -0.7, 0.02)
    leaf.rotation.set(-0.5, side * 0.62, side * -0.48)
    group.add(leaf)
  }

  group.scale.set(0.84, 0.91, 0.84)
  group.rotation.z = -0.06
  return group
}

function mushroomModel() {
  const group = new THREE.Group()
  const stem = new THREE.Mesh(
    new THREE.CylinderGeometry(0.2, 0.32, 2.18, 28, 8),
    physical(0xd8d4b6, { roughness: 0.88 }, "stem"),
  )
  stem.position.y = -0.48
  stem.rotation.z = -0.06
  group.add(stem)

  const capProfile = [
    new THREE.Vector2(0.015, 0.62),
    new THREE.Vector2(0.11, 0.66),
    new THREE.Vector2(0.28, 0.61),
    new THREE.Vector2(0.56, 0.5),
    new THREE.Vector2(0.9, 0.3),
    new THREE.Vector2(1.2, 0.04),
    new THREE.Vector2(1.42, -0.19),
    new THREE.Vector2(1.46, -0.29),
  ]
  const capGeometry = new THREE.LatheGeometry(capProfile, 80)
  const capPositions = capGeometry.attributes.position
  const capColors: number[] = []
  const centerColor = new THREE.Color(0xb9822f)
  const edgeColor = new THREE.Color(0xe2d9b9)
  for (let i = 0; i < capPositions.count; i += 1) {
    const radius = Math.hypot(capPositions.getX(i), capPositions.getZ(i))
    const blend = Math.pow(Math.min(1, radius / 1.46), 0.72)
    const color = centerColor.clone().lerp(edgeColor, blend)
    color.offsetHSL(0, 0, (seeded(i + 4100) - 0.5) * 0.055)
    capColors.push(color.r, color.g, color.b)
  }
  capGeometry.setAttribute(
    "color",
    new THREE.Float32BufferAttribute(capColors, 3),
  )
  const cap = new THREE.Mesh(
    capGeometry,
    physical(
      0xffffff,
      {
        vertexColors: true,
        roughness: 0.48,
        clearcoat: 0.52,
        clearcoatRoughness: 0.26,
      },
      "cap",
    ),
  )
  cap.position.y = 0.76
  cap.rotation.z = -0.04
  group.add(cap)

  const underside = new THREE.Mesh(
    new THREE.CircleGeometry(1.4, 80),
    physical(0xa98b9c, { side: THREE.DoubleSide, roughness: 0.96 }, "gill"),
  )
  underside.rotation.x = Math.PI / 2
  underside.position.y = 0.49
  group.add(underside)

  const gillMaterial = physical(0x806477, { roughness: 1 }, "gill")
  for (let i = 0; i < 52; i += 1) {
    const angle = (i / 52) * Math.PI * 2
    const gillCurve = new THREE.QuadraticBezierCurve3(
      new THREE.Vector3(Math.cos(angle) * 0.24, 0.5, Math.sin(angle) * 0.24),
      new THREE.Vector3(Math.cos(angle) * 0.83, 0.54, Math.sin(angle) * 0.83),
      new THREE.Vector3(Math.cos(angle) * 1.37, 0.47, Math.sin(angle) * 1.37),
    )
    group.add(
      new THREE.Mesh(
        new THREE.TubeGeometry(gillCurve, 14, 0.013, 4, false),
        gillMaterial,
      ),
    )
  }

  const capRim = new THREE.Mesh(
    new THREE.TorusGeometry(1.41, 0.045, 9, 80),
    physical(0xdad0af, { roughness: 0.62, clearcoat: 0.28 }, "cap"),
  )
  capRim.rotation.x = Math.PI / 2
  capRim.position.y = 0.49
  group.add(capRim)

  // Flared partial veil around the upper stem.
  const ring = new THREE.Mesh(
    new THREE.CylinderGeometry(0.42, 0.22, 0.25, 36, 2, true),
    physical(0xb6a6b5, { side: THREE.DoubleSide, roughness: 0.92 }, "gill"),
  )
  ring.position.set(-0.03, 0.14, 0)
  ring.rotation.z = -0.06
  group.add(ring)

  const stemBase = new THREE.Mesh(
    new THREE.SphereGeometry(0.33, 20, 12),
    physical(0xc9c4aa, { roughness: 0.95 }, "stem"),
  )
  stemBase.scale.set(1, 0.65, 1)
  stemBase.position.y = -1.57
  group.add(stemBase)

  group.scale.setScalar(0.9)
  group.rotation.z = 0.06
  return group
}

function peyoteModel() {
  const group = new THREE.Group()
  const geometry = new THREE.SphereGeometry(1.25, 64, 36)
  const positions = geometry.attributes.position
  const vector = new THREE.Vector3()
  for (let i = 0; i < positions.count; i += 1) {
    vector.fromBufferAttribute(positions, i)
    const theta = Math.atan2(vector.z, vector.x)
    const radialDistance = Math.hypot(vector.x, vector.z) / 1.25
    const rib = 1 + Math.cos(theta * 8) * 0.14
    vector.x *= rib
    vector.z *= rib
    const topDepression = vector.y > 0 ? radialDistance * 0.08 : 0
    positions.setXYZ(i, vector.x, vector.y * 0.55 - topDepression, vector.z)
  }
  geometry.computeVertexNormals()
  const body = new THREE.Mesh(
    geometry,
    physical(0x4d8566, { roughness: 0.78, clearcoat: 0.16 }, "cactus"),
  )
  body.position.y = -0.1
  group.add(body)

  const wool = physical(0xd8caa7, { roughness: 1 })
  for (let i = 0; i < 8; i += 1) {
    const angle = (i / 8) * Math.PI * 2
    const ring = 0.82
    const tuft = new THREE.Mesh(new THREE.SphereGeometry(0.055, 8, 6), wool)
    tuft.position.set(
      Math.cos(angle) * ring,
      0.46 - ring * 0.13,
      Math.sin(angle) * ring,
    )
    group.add(tuft)
  }
  // Two rings of narrow petals form the star-shaped peyote flower.
  const petalMaterial = physical(
    0xd7d4ef,
    { roughness: 0.64, side: THREE.DoubleSide },
    "petal",
  )
  for (let i = 0; i < 14; i += 1) {
    const angle = (i / 14) * Math.PI * 2
    const petal = new THREE.Mesh(
      new THREE.SphereGeometry(0.22, 14, 8),
      petalMaterial,
    )
    petal.scale.set(0.42, 0.16, 1.45)
    petal.position.set(Math.cos(angle) * 0.34, 0.68, Math.sin(angle) * 0.34)
    petal.rotation.y = -angle
    petal.rotation.x = -0.08
    group.add(petal)
  }
  for (let i = 0; i < 9; i += 1) {
    const angle = (i / 9) * Math.PI * 2 + 0.18
    const petal = new THREE.Mesh(
      new THREE.SphereGeometry(0.18, 12, 8),
      physical(0xbcbce1, { roughness: 0.7 }, "petal"),
    )
    petal.scale.set(0.42, 0.14, 1.25)
    petal.position.set(Math.cos(angle) * 0.2, 0.75, Math.sin(angle) * 0.2)
    petal.rotation.y = -angle
    group.add(petal)
  }
  const flowerCenter = new THREE.Mesh(
    new THREE.SphereGeometry(0.13, 16, 10),
    physical(0x9f922e, { roughness: 0.9 }),
  )
  flowerCenter.scale.y = 0.45
  flowerCenter.position.y = 0.78
  group.add(flowerCenter)
  group.rotation.x = 0.1
  return group
}

function createTrumpetGeometry() {
  const rows = 36
  const segments = 80
  const positions: number[] = []
  const uvs: number[] = []
  const indices: number[] = []
  for (let row = 0; row <= rows; row += 1) {
    const v = row / rows
    const smooth = v * v * (3 - 2 * v)
    for (let segment = 0; segment <= segments; segment += 1) {
      const u = segment / segments
      const angle = u * Math.PI * 2
      const lobe = Math.cos(angle * 5)
      const baseRadius = 0.13 + smooth * 0.72 + Math.pow(v, 4) * 0.28
      const radius = baseRadius * (1 + lobe * 0.085 * Math.pow(v, 4))
      const y = 1.34 - v * 2.38 + lobe * 0.16 * Math.pow(v, 7)
      positions.push(Math.cos(angle) * radius, y, Math.sin(angle) * radius)
      uvs.push(u, 1 - v)
    }
  }
  for (let row = 0; row < rows; row += 1) {
    for (let segment = 0; segment < segments; segment += 1) {
      const a = row * (segments + 1) + segment
      const b = a + segments + 1
      indices.push(a, b, a + 1, b, b + 1, a + 1)
    }
  }
  const geometry = new THREE.BufferGeometry()
  geometry.setAttribute(
    "position",
    new THREE.Float32BufferAttribute(positions, 3),
  )
  geometry.setAttribute("uv", new THREE.Float32BufferAttribute(uvs, 2))
  geometry.setIndex(indices)
  geometry.computeVertexNormals()
  return geometry
}

function brugmansiaModel() {
  const group = new THREE.Group()
  const petalMaterial = physical(
    0xa99be1,
    {
      side: THREE.DoubleSide,
      roughness: 0.48,
      clearcoat: 0.38,
      transmission: 0.055,
      thickness: 0.28,
    },
    "petal",
  )
  group.add(new THREE.Mesh(createTrumpetGeometry(), petalMaterial))

  const ribMaterial = physical(0xd7d0f2, {
    roughness: 0.52,
    clearcoat: 0.28,
  })
  for (let i = 0; i < 5; i += 1) {
    const angle = (i / 5) * Math.PI * 2
    const rib = new THREE.CatmullRomCurve3([
      new THREE.Vector3(Math.cos(angle) * 0.15, 1.18, Math.sin(angle) * 0.15),
      new THREE.Vector3(Math.cos(angle) * 0.32, 0.3, Math.sin(angle) * 0.32),
      new THREE.Vector3(Math.cos(angle) * 0.72, -0.58, Math.sin(angle) * 0.72),
      new THREE.Vector3(Math.cos(angle) * 1.03, -1.02, Math.sin(angle) * 1.03),
    ])
    group.add(
      new THREE.Mesh(
        new THREE.TubeGeometry(rib, 24, 0.018, 5, false),
        ribMaterial,
      ),
    )
  }

  // The five recurved tips are the defining silhouette in the reference.
  for (let i = 0; i < 5; i += 1) {
    const angle = (i / 5) * Math.PI * 2
    const horn = new THREE.CubicBezierCurve3(
      new THREE.Vector3(Math.cos(angle) * 1.02, -1.02, Math.sin(angle) * 1.02),
      new THREE.Vector3(Math.cos(angle) * 1.3, -0.9, Math.sin(angle) * 1.3),
      new THREE.Vector3(Math.cos(angle) * 1.26, -0.55, Math.sin(angle) * 1.26),
      new THREE.Vector3(Math.cos(angle) * 1.12, -0.43, Math.sin(angle) * 1.12),
    )
    group.add(
      new THREE.Mesh(
        new THREE.TubeGeometry(horn, 18, 0.055, 8, false),
        petalMaterial,
      ),
    )
    const curledTip = new THREE.Mesh(
      new THREE.SphereGeometry(0.07, 12, 8),
      petalMaterial,
    )
    curledTip.position.set(
      Math.cos(angle) * 1.12,
      -0.43,
      Math.sin(angle) * 1.12,
    )
    group.add(curledTip)
  }

  const greenMaterial = physical(
    0x76ad5c,
    { side: THREE.DoubleSide, roughness: 0.82 },
    "leaf",
  )
  const calyx = new THREE.Mesh(
    new THREE.ConeGeometry(0.27, 0.76, 5, 3, true),
    greenMaterial,
  )
  calyx.position.y = 1.18
  group.add(calyx)

  const stem = new THREE.Mesh(
    new THREE.CylinderGeometry(0.075, 0.11, 0.7, 18),
    greenMaterial,
  )
  stem.position.y = 1.7
  group.add(stem)

  for (let i = 0; i < 2; i += 1) {
    const leaf = createLeaf(0x356d3c)
    leaf.scale.set(0.78, 0.86, 0.78)
    leaf.position.set(i === 0 ? -0.38 : 0.36, 1.55 + i * 0.16, -0.1)
    leaf.rotation.set(-0.3, i === 0 ? -0.5 : 0.55, i === 0 ? 1.05 : -1.08)
    group.add(leaf)
  }

  group.scale.setScalar(0.82)
  group.rotation.set(0.08, -0.08, 0.08)
  return group
}

function ayahuascaModel() {
  const group = new THREE.Group()
  const bark = physical(0x5d321e, { roughness: 0.98 }, "bark")
  const wood = physical(0xa8642e, { roughness: 0.94 }, "wood")
  const cutShape = new THREE.Shape()
  const lobes = 9
  for (let i = 0; i <= 96; i += 1) {
    const angle = (i / 96) * Math.PI * 2
    const radius =
      1.05 + Math.sin(angle * lobes) * 0.13 + Math.sin(angle * 3 + 0.7) * 0.055
    const x = Math.cos(angle) * radius
    const y = Math.sin(angle) * radius
    if (i === 0) cutShape.moveTo(x, y)
    else cutShape.lineTo(x, y)
  }

  // A shallow, lobed vine section keeps the diagnostic cut face visible.
  const section = new THREE.Mesh(
    new THREE.ExtrudeGeometry(cutShape, {
      depth: 0.68,
      bevelEnabled: true,
      bevelSegments: 3,
      steps: 1,
      bevelSize: 0.08,
      bevelThickness: 0.08,
      curveSegments: 64,
    }),
    [wood, bark],
  )
  section.position.z = -0.34
  group.add(section)

  const veinMaterial = physical(0x5a2d1b, {
    roughness: 1,
    emissive: 0x140804,
  })
  for (let i = 0; i < 18; i += 1) {
    const angle = (i / 18) * Math.PI * 2 + seeded(i + 40) * 0.1
    const endRadius = 0.86 + seeded(i + 70) * 0.14
    const curve = new THREE.QuadraticBezierCurve3(
      new THREE.Vector3(0.04, 0, 0.43),
      new THREE.Vector3(
        Math.cos(angle + 0.12) * 0.48,
        Math.sin(angle + 0.12) * 0.48,
        0.445,
      ),
      new THREE.Vector3(
        Math.cos(angle) * endRadius,
        Math.sin(angle) * endRadius,
        0.43,
      ),
    )
    group.add(
      new THREE.Mesh(
        new THREE.TubeGeometry(curve, 10, 0.018, 5, false),
        veinMaterial,
      ),
    )
  }

  for (let i = 1; i <= 4; i += 1) {
    const ring = new THREE.Mesh(
      new THREE.TorusGeometry(i * 0.18, 0.012, 5, 64),
      veinMaterial,
    )
    ring.position.z = 0.435
    ring.scale.set(1, 0.88 + i * 0.02, 1)
    group.add(ring)
  }

  const center = new THREE.Mesh(
    new THREE.CircleGeometry(0.13, 24),
    physical(0x6d3820, { roughness: 1 }),
  )
  center.position.z = 0.45
  group.add(center)

  group.rotation.set(-0.18, 0.22, -0.13)
  group.scale.setScalar(1.08)
  return group
}

function buildModel(id: PlantId) {
  if (id === "cannabis") return cannabisModel()
  if (id === "hongos") return mushroomModel()
  if (id === "cactaceas") return peyoteModel()
  if (id === "solanaceas") return brugmansiaModel()
  return ayahuascaModel()
}

export default function ThreeSpecimen({
  id,
  rotationX,
  rotationY,
}: {
  id: PlantId
  rotationX: number
  rotationY: number
}) {
  const mountRef = useRef<HTMLDivElement>(null)
  const rotationRef = useRef({ x: rotationX, y: rotationY })

  useEffect(() => {
    rotationRef.current = { x: rotationX, y: rotationY }
  }, [rotationX, rotationY])

  useEffect(() => {
    const mount = mountRef.current
    if (!mount) return

    const scene = new THREE.Scene()
    const camera = new THREE.PerspectiveCamera(36, 1, 0.1, 100)
    camera.position.set(0, 0.25, 5.75)

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true })
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
    renderer.outputColorSpace = THREE.SRGBColorSpace
    renderer.shadowMap.enabled = true
    renderer.shadowMap.type = THREE.PCFSoftShadowMap
    mount.appendChild(renderer.domElement)

    const model = buildModel(id)
    scene.add(model)

    const ambient = new THREE.HemisphereLight(0xe9dcff, 0x16091f, 2.4)
    scene.add(ambient)
    const key = new THREE.DirectionalLight(0xffffff, 4.5)
    key.position.set(3.5, 4, 5)
    key.castShadow = true
    key.shadow.mapSize.set(1024, 1024)
    key.shadow.camera.near = 0.1
    key.shadow.camera.far = 14
    scene.add(key)
    const rim = new THREE.PointLight(0x22cc44, 18, 10)
    rim.position.set(-3, 0.5, -2)
    scene.add(rim)
    const warm = new THREE.PointLight(0xf4ff00, 8, 8)
    warm.position.set(2.5, -2, 2)
    scene.add(warm)
    const fill = new THREE.DirectionalLight(0x9e79ff, 2.5)
    fill.position.set(-4, 1, 3)
    scene.add(fill)

    const shadowFloor = new THREE.Mesh(
      new THREE.PlaneGeometry(5, 5),
      new THREE.ShadowMaterial({ color: 0x000000, opacity: 0.38 }),
    )
    shadowFloor.rotation.x = -Math.PI / 2
    shadowFloor.position.y = -1.58
    shadowFloor.receiveShadow = true
    scene.add(shadowFloor)

    model.traverse((object) => {
      if (object instanceof THREE.Mesh) {
        object.castShadow = true
        object.receiveShadow = true
      }
    })

    const reducedMotion = window.matchMedia(
      "(prefers-reduced-motion: reduce)",
    ).matches
    const clock = new THREE.Clock()
    let frame = 0

    const resize = () => {
      const width = mount.clientWidth
      const height = mount.clientHeight
      renderer.setSize(width, height, false)
      camera.aspect = width / Math.max(height, 1)
      camera.updateProjectionMatrix()
    }
    const observer = new ResizeObserver(resize)
    observer.observe(mount)
    resize()

    const animate = () => {
      const elapsed = clock.getElapsedTime()
      if (!reducedMotion) {
        model.position.y = Math.sin(elapsed * 0.85) * 0.055
      }
      model.rotation.x +=
        (THREE.MathUtils.degToRad(rotationRef.current.x) - model.rotation.x) *
        0.09
      model.rotation.y +=
        (THREE.MathUtils.degToRad(rotationRef.current.y) +
          (reducedMotion ? 0 : elapsed * 0.11) -
          model.rotation.y) *
        0.09
      renderer.render(scene, camera)
      frame = requestAnimationFrame(animate)
    }
    animate()

    return () => {
      cancelAnimationFrame(frame)
      observer.disconnect()
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh) {
          object.geometry.dispose()
          const materials = Array.isArray(object.material)
            ? object.material
            : [object.material]
          materials.forEach((material) => material.dispose())
        }
      })
      renderer.dispose()
      renderer.domElement.remove()
    }
  }, [id])

  return <div className="three-canvas" ref={mountRef} aria-hidden="true" />
}
